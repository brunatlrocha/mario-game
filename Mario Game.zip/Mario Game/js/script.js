const jump = () 
document.addEventListener ('keydown', jump)